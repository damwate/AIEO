// test-session-budget.mjs — 会话上下文预算账本验收测试（T1-T7 业务语义 + C1-C10 并发/故障专项）
// 设计依据：AIEO b-20261122-session-ctx-mgmt design-r2.md §5（CTX-R1..R9 冻结口径）
// 运行：node --test monitor/test-session-budget.mjs
import { test, describe } from "node:test";
import assert from "node:assert/strict";
import { mkdtempSync, writeFileSync, readFileSync, readdirSync } from "node:fs";
import { tmpdir } from "node:os";
import { join, dirname } from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";
import { spawnSync } from "node:child_process";
import { DatabaseSync } from "node:sqlite";
import { assessLedger, recordTurn, readLedger, thresholds } from "./session-budget.mjs";

const MODULE_URL = pathToFileURL(join(dirname(fileURLToPath(import.meta.url)), "session-budget.mjs")).href;

function tempDir() {
  return mkdtempSync(join(tmpdir(), "session-budget-test-"));
}
function writeWorker(dir, name, code) {
  const p = join(dir, name);
  writeFileSync(p, code);
  return p;
}

describe("T1-T7 业务验收", () => {
  test("T1: 7 条消息累计>48KB → HARD 拦截语义", () => {
    const dir = tempDir();
    for (let i = 0; i < 7; i++) recordTurn("t1-uuid", { inBytes: 4000, outBytes: 4000 }, { dir });
    const a = assessLedger("t1-uuid", { dir });
    assert.equal(a.state, "HARD");
    assert.equal(a.totals.turns, 7);
    assert.ok(a.totals.totalBytes >= 49152);
  });
  test("T2: 仅 2 条但单轮输出 10KB → max_turn_bytes 正确反映", () => {
    const dir = tempDir();
    recordTurn("t2-uuid", { inBytes: 100, outBytes: 100 }, { dir });
    recordTurn("t2-uuid", { inBytes: 0, outBytes: 10240 }, { dir });
    const a = assessLedger("t2-uuid", { dir });
    assert.equal(a.totals.turns, 2);
    assert.equal(a.totals.maxTurnBytes, 10240);
    assert.equal(a.state, "NORMAL");
  });
  test("T3: 账本损坏 → LEDGER_UNREADABLE（fail-closed，不静默建空库覆盖）", () => {
    const dir = tempDir();
    recordTurn("t3-uuid", { inBytes: 10, outBytes: 10 }, { dir });
    const dbFile = join(dir, "session-usage.db");
    const junk = Buffer.alloc(64, 0xff);
    const orig = readFileSync(dbFile);
    writeFileSync(dbFile, Buffer.concat([junk, orig.subarray(64)]));
    assert.throws(() => assessLedger("t3-uuid", { dir }), /LEDGER_UNREADABLE/);
    assert.throws(() => recordTurn("t3-uuid", { inBytes: 5, outBytes: 5 }, { dir }), /LEDGER_UNREADABLE/);
    assert.throws(() => assessLedger("t3-uuid", { dir }), /LEDGER_UNREADABLE/);
  });
  test("T5: 新会话 UUID → 独立账本行建立", () => {
    const dir = tempDir();
    recordTurn("t5-a", { inBytes: 10, outBytes: 10 }, { dir });
    recordTurn("t5-b", { inBytes: 20, outBytes: 20 }, { dir });
    assert.equal(assessLedger("t5-a", { dir }).totals.totalBytes, 20);
    assert.equal(assessLedger("t5-b", { dir }).totals.totalBytes, 40);
  });
  test("T6: 同 UUID 跨仓共享=同一行；异 UUID 隔离", () => {
    const dir = tempDir();
    recordTurn("t6-shared", { inBytes: 5, outBytes: 5 }, { dir });
    recordTurn("t6-shared", { inBytes: 5, outBytes: 5 }, { dir });
    assert.equal(assessLedger("t6-shared", { dir }).totals.turns, 2);
    assert.equal(assessLedger("t6-other", { dir }).totals.turns, 0);
  });
  test("T7: WARN 后新会话 → 独立新行，互不影响（自包含简报恢复由派单流程验收）", () => {
    const dir = tempDir();
    for (let i = 0; i < 6; i++) recordTurn("t7-old", { inBytes: 4000, outBytes: 4000 }, { dir });
    assert.equal(assessLedger("t7-old", { dir }).state, "WARN");
    recordTurn("t7-new", { inBytes: 10, outBytes: 10 }, { dir });
    assert.equal(assessLedger("t7-new", { dir }).state, "NORMAL");
    assert.equal(assessLedger("t7-old", { dir }).state, "WARN");
  });
});

describe("C1-C10 并发与故障专项", () => {
  test("C1: 两独立进程并发更新同 UUID → 累计不丢失", () => {
    const dir = tempDir();
    const worker = writeWorker(dir, "c1-worker.mjs", `
      import { recordTurn } from ${JSON.stringify(MODULE_URL)};
      for (let i = 0; i < 5; i++) recordTurn("c1-uuid", { inBytes: 500, outBytes: 500 }, { dir: ${JSON.stringify(dir)} });
      console.log("done");
    `);
    const p1 = spawnSync(process.execPath, [worker]);
    const p2 = spawnSync(process.execPath, [worker]);
    assert.equal(p1.status, 0, p1.stderr?.toString());
    assert.equal(p2.status, 0, p2.stderr?.toString());
    const a = assessLedger("c1-uuid", { dir });
    assert.equal(a.totals.turns, 10, "两进程 10 轮全部累计");
    assert.equal(a.totals.totalBytes, 10 * 1000);
  });
  test("C2: 写事务被占用 → busy 预算内 LEDGER_BUSY_TIMEOUT（fail-closed）", () => {
    const dir = tempDir();
    recordTurn("c2-uuid", { inBytes: 10, outBytes: 10 }, { dir });
    const blocker = new DatabaseSync(join(dir, "session-usage.db"));
    blocker.exec("PRAGMA busy_timeout=100");
    blocker.exec("BEGIN IMMEDIATE");
    blocker.exec("INSERT INTO ledger(uuid,turns,in_bytes,out_bytes,total_bytes,max_turn_bytes,gen,first_at,last_at,budget_version) VALUES('zzz',0,0,0,0,0,0,'x','x',1)");
    const t0 = performance.now();
    assert.throws(() => recordTurn("c2-uuid", { inBytes: 10, outBytes: 10 }, { dir }), /LEDGER_BUSY_TIMEOUT/);
    const wall = performance.now() - t0;
    assert.ok(wall <= 3500, `T_wall=${Math.round(wall)}ms ≤ 3000ms+测试余量`);
    blocker.exec("ROLLBACK");
    blocker.close();
  });
  test("C3: 写事务进程异常退出 → 自动回滚，其他进程继续写", () => {
    const dir = tempDir();
    recordTurn("c3-uuid", { inBytes: 10, outBytes: 10 }, { dir });
    const die = writeWorker(dir, "c3-die.mjs", `
      import { DatabaseSync } from "node:sqlite";
      const db = new DatabaseSync(${JSON.stringify(join(dir, "session-usage.db"))});
      db.exec("PRAGMA busy_timeout=100");
      db.exec("BEGIN IMMEDIATE");
      db.exec("UPDATE ledger SET turns=turns+1 WHERE uuid='c3-uuid'");
      process.exit(1);
    `);
    const p = spawnSync(process.execPath, [die]);
    assert.equal(p.status, 1);
    assert.equal(assessLedger("c3-uuid", { dir }).totals.turns, 1, "未提交事务已回滚");
    recordTurn("c3-uuid", { inBytes: 10, outBytes: 10 }, { dir });
    assert.equal(assessLedger("c3-uuid", { dir }).totals.turns, 2, "其他进程继续写");
  });
  test("C4: A 事务外读 G 后暂停；B 提交 G+1；A 恢复条件更新 0 行放弃", () => {
    const dir = tempDir();
    recordTurn("c4-uuid", { inBytes: 10, outBytes: 10 }, { dir });
    const g1 = readLedger("c4-uuid", { dir }).gen;
    recordTurn("c4-uuid", { inBytes: 20, outBytes: 20 }, { dir });
    const db = new DatabaseSync(join(dir, "session-usage.db"));
    db.exec("PRAGMA busy_timeout=100");
    db.exec("BEGIN IMMEDIATE");
    const r = db.prepare("UPDATE ledger SET turns=turns+1,gen=gen+1 WHERE uuid=? AND gen=?").run("c4-uuid", g1);
    db.exec("COMMIT");
    db.close();
    assert.equal(r.changes, 0, "旧 gen 条件更新必命中 0 行");
    const a = assessLedger("c4-uuid", { dir });
    assert.equal(a.totals.turns, 2, "B 的提交完好，A 的旧写入未覆盖");
  });
  test("C5: 无旧协议残留（无锁文件/token/TTL 产物）", () => {
    const dir = tempDir();
    recordTurn("c5-uuid", { inBytes: 10, outBytes: 10 }, { dir });
    for (const f of readdirSync(dir)) {
      assert.ok(!/\.lock$|\.takeover|\.json$/.test(f), `无旧协议产物: ${f}`);
    }
    assert.ok(readdirSync(dir).includes("session-usage.db"));
  });
  test("C7: 库损坏 → LEDGER_UNREADABLE 不静默建空库覆盖", () => {
    const dir = tempDir();
    recordTurn("c7-uuid", { inBytes: 10, outBytes: 10 }, { dir });
    const dbFile = join(dir, "session-usage.db");
    writeFileSync(dbFile, Buffer.alloc(128, 0x00));
    assert.throws(() => assessLedger("c7-uuid", { dir }), /LEDGER_UNREADABLE/);
    assert.throws(() => recordTurn("c7-uuid", { inBytes: 1, outBytes: 1 }, { dir }), /LEDGER_UNREADABLE/);
  });
  test("C8: 两进程并发首次写同 UUID → 唯一约束捕获→重读→gen 更新，两轮都累计", () => {
    const dir = tempDir();
    const worker = writeWorker(dir, "c8-worker.mjs", `
      import { recordTurn } from ${JSON.stringify(MODULE_URL)};
      recordTurn("c8-uuid", { inBytes: 700, outBytes: 700 }, { dir: ${JSON.stringify(dir)} });
      console.log("done");
    `);
    const p1 = spawnSync(process.execPath, [worker]);
    const p2 = spawnSync(process.execPath, [worker]);
    assert.equal(p1.status, 0, p1.stderr?.toString());
    assert.equal(p2.status, 0, p2.stderr?.toString());
    const a = assessLedger("c8-uuid", { dir });
    assert.equal(a.totals.turns, 2, "两 turn 都在账本");
    assert.equal(a.totals.totalBytes, 2800);
  });
  test("C10: BUSY 硬上限 T_wall ≤ 3000ms（busy_timeout 调大也不突破，deadline 机制生效）", () => {
    const dir = tempDir();
    recordTurn("c10-uuid", { inBytes: 10, outBytes: 10 }, { dir });
    const blocker = new DatabaseSync(join(dir, "session-usage.db"));
    blocker.exec("PRAGMA busy_timeout=40000");
    blocker.exec("BEGIN IMMEDIATE");
    blocker.exec("INSERT INTO ledger(uuid,turns,in_bytes,out_bytes,total_bytes,max_turn_bytes,gen,first_at,last_at,budget_version) VALUES('yyy',0,0,0,0,0,0,'x','x',1)");
    const t0 = performance.now();
    assert.throws(() => recordTurn("c10-uuid", { inBytes: 10, outBytes: 10 }, { dir }), /LEDGER_BUSY_TIMEOUT/);
    const wall = performance.now() - t0;
    assert.ok(wall <= 3000, `T_wall=${Math.round(wall)}ms ≤ 3000ms`);
    blocker.exec("ROLLBACK");
    blocker.close();
  });
});

describe("阈值与配置校验", () => {
  test("非法 env 阈值不得静默放宽门槛", () => {
    assert.throws(() => thresholds({ SESSION_BUDGET_WARN: "0", SESSION_BUDGET_HARD: "10" }), /SESSION_BUDGET_CONFIG_INVALID/);
    assert.throws(() => thresholds({ SESSION_BUDGET_WARN: "100", SESSION_BUDGET_HARD: "50" }), /SESSION_BUDGET_CONFIG_INVALID/);
    const ok = thresholds({ SESSION_BUDGET_WARN: "100", SESSION_BUDGET_HARD: "200" });
    assert.equal(ok.warnBytes, 100);
    assert.equal(ok.hardBytes, 200);
  });
});
