// session-budget.mjs — 会话上下文预算账本（SQLite 唯一权威账本）
// 设计依据：AIEO basic/tasks/b-20261122-session-ctx-mgmt/design-r2.md v5-v9（CTX-R1..R9 裁定链，R9 设计 PASS+编码授权）
// 不可变约束（R9 冻结）：
//   1. SQLite 是唯一权威账本（无 JSON/文件锁/token/TTL/接管协议）
//   2. GEN_CONFLICT 不允许丢失已确认 turn（放弃旧快照写入尝试→重读重算重试，3 轮耗尽上抛）
//   3. 首写唯一约束冲突必须显式 ROLLBACK 后重读再走 gen 条件更新
//   4. ROLLBACK 失败必须废弃连接
//   5. COMMIT 报错必须废弃连接（单出口：isTransaction 仅决定是否尝试 ROLLBACK，不作为复用依据）
//   6. UNCERTAIN 不得自动放行
//   7. BUSY 超时必须 fail-closed（绝对 deadline 3000ms 运行时强制）
// 错误码：LEDGER_UNREADABLE / LEDGER_BUSY_TIMEOUT / LEDGER_GEN_CONFLICT_EXHAUSTED /
//         LEDGER_COMMIT_UNCERTAIN / SESSION_BUDGET_EXCEEDED(HARD 拒发语义由调用方执行)
import { DatabaseSync } from "node:sqlite";
import { mkdirSync, readdirSync } from "node:fs";
import { join, dirname } from "node:path";
import { homedir } from "node:os";
import { randomUUID } from "node:crypto";

export const BUDGET_VERSION = 1;
// 首版工程预算估计值（非模型窗口实际容量；真实样本校准后 bump budget_version）
const DEFAULT_WARN_BYTES = 24576; // 24KB
const DEFAULT_HARD_BYTES = 49152; // 48KB
// BUSY 等待预算（R8 绝对 deadline 运行时强制）
const DEADLINE_MS = 3000;         // 硬上限：首次受阻调用→异常抛出的完整路径
const MIN_REMAINING_MS = 200;     // 剩余预算低于此值即停止重试
const BASE_BUSY_MS = 500;         // 单次 busy_timeout 上限（动态截断为 min(500, 剩余)）
const RETRY_INTERVAL_MS = 200;
const MAX_ATTEMPTS = 4;           // 1 次初始 + 3 次重试
const GEN_CONFLICT_MAX_ROUNDS = 3;

function dbPath() {
  return join(homedir(), ".agents", "session-usage", "session-usage.db");
}

function validateThresholds(warn, hard) {
  // R1 裁定：配置值须校验，非法值不得静默放宽门槛
  if (!Number.isFinite(warn) || !Number.isFinite(hard) || warn <= 0 || hard <= warn) {
    throw new Error(`SESSION_BUDGET_CONFIG_INVALID: warn=${warn} hard=${hard}`);
  }
}

export function thresholds(env = process.env) {
  const warn = env.SESSION_BUDGET_WARN !== undefined ? Number(env.SESSION_BUDGET_WARN) : DEFAULT_WARN_BYTES;
  const hard = env.SESSION_BUDGET_HARD !== undefined ? Number(env.SESSION_BUDGET_HARD) : DEFAULT_HARD_BYTES;
  validateThresholds(warn, hard);
  return { warnBytes: warn, hardBytes: hard, budgetVersion: BUDGET_VERSION };
}

function openDbFor(dirOverride) {
  // 连接工厂可注入（测试故障注入用）；生产=每调用新建短连接（COMMIT 报错一律废弃，单出口）
  const dir = dirOverride ?? join(homedir(), ".agents", "session-usage");
  mkdirSync(dir, { recursive: true });
  const db = new DatabaseSync(join(dir, "session-usage.db"));
  db.exec("PRAGMA journal_mode=WAL");
  return db;
}

function ensureSchema(db) {
  db.exec(`CREATE TABLE IF NOT EXISTS ledger(
    uuid TEXT PRIMARY KEY,
    turns INTEGER NOT NULL,
    in_bytes INTEGER NOT NULL,
    out_bytes INTEGER NOT NULL,
    total_bytes INTEGER NOT NULL,
    max_turn_bytes INTEGER NOT NULL,
    open_turn_bytes INTEGER NOT NULL DEFAULT 0,
    gen INTEGER NOT NULL,
    first_at TEXT NOT NULL,
    last_at TEXT NOT NULL,
    budget_version INTEGER NOT NULL
  )`);
}

function rowToLedger(row) {
  return {
    uuid: row.uuid, turns: row.turns, inBytes: row.in_bytes, outBytes: row.out_bytes,
    totalBytes: row.total_bytes, maxTurnBytes: row.max_turn_bytes, openTurnBytes: row.open_turn_bytes, gen: row.gen,
    firstAt: row.first_at, lastAt: row.last_at, budgetVersion: row.budget_version,
  };
}

function isTransientBusy(e) {
  return /database is locked|SQLITE_BUSY/i.test(String(e?.message || e));
}

function readOn(db, uuid) {
  // 在既有连接上读取（recordTurn 连接复用路径）；locked=瞬态 BUSY（可重试）→ BUSY_TRANSIENT；
  // 其余（损坏/IO）= LEDGER_UNREADABLE（fail-closed）
  try {
    ensureSchema(db);
    const row = db.prepare("SELECT * FROM ledger WHERE uuid=?").get(uuid);
    return row ? rowToLedger(row) : null;
  } catch (e) {
    if (isTransientBusy(e)) throw new Error(`LEDGER_BUSY_TRANSIENT: ${e.message}`);
    throw new Error(`LEDGER_UNREADABLE: ${e.message}`);
  }
}

// 读取账本（事务外普通 SELECT）。库不存在/无该行=可证明为空 → null。
// 库打不开/损坏/schema 不兼容 → LEDGER_UNREADABLE（fail-closed，不静默建空库覆盖）。
export function readLedger(uuid, opts = {}) {
  if (!uuid || typeof uuid !== "string" || !/^[0-9a-zA-Z_-]{3,80}$/.test(uuid)) {
    throw new Error("LEDGER_UUID_INVALID");
  }
  let db;
  try {
    db = opts.openDb ? opts.openDb() : openDbFor(opts.dir);
    ensureSchema(db);
    const row = db.prepare("SELECT * FROM ledger WHERE uuid=?").get(uuid);
    return row ? rowToLedger(row) : null;
  } catch (e) {
    if (String(e.message).startsWith("LEDGER_")) throw e;
    throw new Error(`LEDGER_UNREADABLE: ${e.message}`);
  } finally {
    try { db?.close(); } catch {}
  }
}

// assess：状态判定（NORMAL/WARN/HARD）。账本缺失=NORMAL(空，可证明)；读取失败=LEDGER_UNREADABLE 上抛（P1-3 fail-closed）。
export function assessLedger(uuid, opts = {}) {
  const th = thresholds(opts.env);
  const ledger = readLedger(uuid, opts);
  if (!ledger) {
    return { state: "NORMAL", totals: { turns: 0, inBytes: 0, outBytes: 0, totalBytes: 0, maxTurnBytes: 0 }, thresholds: th, provableEmpty: true };
  }
  const total = ledger.totalBytes;
  const state = total >= th.hardBytes ? "HARD" : total >= th.warnBytes ? "WARN" : "NORMAL";
  return { state, totals: { turns: ledger.turns, inBytes: ledger.inBytes, outBytes: ledger.outBytes, totalBytes: total, maxTurnBytes: ledger.maxTurnBytes }, thresholds: th, provableEmpty: false };
}

function isUniqueConstraintError(e) {
  // R5-R7：按错误码精确匹配主键/唯一约束，不得把所有 SQLITE_CONSTRAINT 当首写冲突
  const code = e?.code || "";
  const msg = String(e?.message || "");
  return code === "ERR_SQLITE_ERROR" && /UNIQUE constraint failed.*ledger\.uuid|PRIMARY KEY/i.test(msg);
}

// recordTurn：原子条件更新（设计 §2 时序 v9）
// 1. 事务外读快照 → 2. 事务外纯内存计算（禁止外部 I/O）→ 3. BEGIN IMMEDIATE（动态 busy_timeout=min(500,剩余)）
//    → 4. INSERT（首写）/ UPDATE…WHERE uuid AND gen=G（gen 条件更新）→ 5. changes==1 COMMIT / ==0 ROLLBACK 重读重算
//    → COMMIT 报错：一律废弃连接（单出口），isTransaction 仅决定是否尝试 ROLLBACK，LEDGER_COMMIT_UNCERTAIN
// 绝对 deadline：T0=performance.now()，3000ms 硬上限，剩余<200ms 即停，计时覆盖首次受阻调用→异常抛出完整路径
export function recordTurn(uuid, { inBytes = 0, outBytes = 0 }, opts = {}) {
  // opts.completeOpenTurn=true：完成已开启的逻辑轮（发送时点已记 in）——更新该轮而非新建：
  // turns 不变、out_bytes/total 累加、max_turn_bytes=max(峰值, open_turn+out)、open_turn 归零。
  // 无开启轮（发送侧 UNCERTAIN/崩溃未记）→ 回落新轮语义（out 单独计，少记 in 如实承认）。
  if (!uuid || typeof uuid !== "string" || !/^[0-9a-zA-Z_-]{3,80}$/.test(uuid)) {
    throw new Error("LEDGER_UUID_INVALID");
  }
  if (!Number.isFinite(inBytes) || !Number.isFinite(outBytes) || inBytes < 0 || outBytes < 0) {
    throw new Error("LEDGER_BYTES_INVALID");
  }
  const th = thresholds(opts.env);
  const deadline = performance.now() + DEADLINE_MS;
  const remaining = () => deadline - performance.now();
  const dir = opts.dir ?? join(homedir(), ".agents", "session-usage");
  const openConn = opts.openDb ?? (() => openDbFor(dir));
  const now = () => new Date().toISOString();

  let genConflictRounds = 0;
  let attempt = 0;
  let conn = null;

  const discardConn = () => { // 单出口：COMMIT 报错/ROLLBACK 失败的连接一律废弃不复用
    try { conn?.close(); } catch {}
    conn = null;
  };
  const newConn = () => {
    try {
      conn = openConn();
      ensureSchema(conn); // 损坏库在此抛 → 统一映射 LEDGER_UNREADABLE；locked=瞬态 BUSY（可重试）
    } catch (e) {
      discardConn();
      if (isTransientBusy(e)) throw new Error(`LEDGER_BUSY_TRANSIENT: open ${e.message}`);
      throw new Error(`LEDGER_UNREADABLE: ` + (e.message || e.code || "open_or_schema_failed"));
    }
  };

  try {
    while (true) {
      attempt += 1;
      if (remaining() < MIN_REMAINING_MS || attempt > MAX_ATTEMPTS) {
        throw new Error(`LEDGER_BUSY_TIMEOUT: deadline_exhausted attempts=${attempt} wall=${Math.round(DEADLINE_MS - remaining())}ms`);
      }
      // 连接复用（同一次 recordTurn 内）；仅错误路径废弃后新建；并发 open 争用=瞬态按预算重试
      if (!conn) {
        try {
          newConn();
        } catch (e) {
          if (String(e.message).startsWith("LEDGER_BUSY_TRANSIENT")) {
            if (remaining() < MIN_REMAINING_MS || attempt >= MAX_ATTEMPTS) {
              throw new Error(`LEDGER_BUSY_TIMEOUT: open_contention ${e.message}`);
            }
            sleepSync(RETRY_INTERVAL_MS);
            continue;
          }
          throw e;
        }
      }
      // 动态 busy_timeout：min(500ms, 剩余预算-400ms 安全余量)。
      // 实测 BEGIN IMMEDIATE 实际阻塞 ≈ busy_timeout+120ms（pragma 超越），预留防止最后一次等待突破 3000ms 硬上限。
      const BUSY_RESERVE_MS = 400;
      const busyMs = Math.max(0, Math.min(BASE_BUSY_MS, Math.round(remaining() - BUSY_RESERVE_MS)));
      try {
        conn.exec(`PRAGMA busy_timeout=${busyMs}`);
      } catch (e) {
        discardConn(); // P0-2：设置失败不得静默吞掉——否则连接用默认等待参数可能突破 3000ms 硬上限
        throw new Error(`LEDGER_BUSY_TIMEOUT: busy_pragma_failed ${e.message}`);
      }

      // ① 事务外读快照（同连接；每次尝试都从最新已提交状态出发）；并发下 open/read 可能瞬态 locked → 按预算重试
      let ledger;
      try {
        ledger = readOn(conn, uuid);
      } catch (e) {
        if (String(e.message).startsWith("LEDGER_BUSY_TRANSIENT")) {
          if (remaining() < MIN_REMAINING_MS || attempt >= MAX_ATTEMPTS) {
            discardConn();
            throw new Error(`LEDGER_BUSY_TIMEOUT: read_contention ${e.message}`);
          }
          sleepSync(RETRY_INTERVAL_MS);
          continue;
        }
        throw e;
      }
      // ② 事务外纯内存计算（无外部 I/O）
      const completing = Boolean(opts.completeOpenTurn && ledger && ledger.openTurnBytes > 0);
      const turnBytes = completing ? ledger.openTurnBytes + outBytes : inBytes + outBytes;
      const next = ledger
        ? {
            turns: completing ? ledger.turns : ledger.turns + 1,
            inBytes: ledger.inBytes + inBytes, outBytes: ledger.outBytes + outBytes,
            totalBytes: ledger.totalBytes + turnBytes,
            maxTurnBytes: Math.max(ledger.maxTurnBytes, turnBytes),
            openTurnBytes: completing ? 0 : inBytes,
            gen: ledger.gen + 1, firstAt: ledger.firstAt,
          }
        : {
            turns: 1, inBytes, outBytes, totalBytes: turnBytes, maxTurnBytes: turnBytes,
            openTurnBytes: inBytes,
            gen: 1, firstAt: now(),
          };
      next.lastAt = now();

      // ③ BEGIN IMMEDIATE（失败=无事务，连接仍可用，按预算重试）
      try {
        conn.exec("BEGIN IMMEDIATE");
      } catch (e) {
        if (remaining() < MIN_REMAINING_MS || attempt >= MAX_ATTEMPTS) {
          discardConn();
          throw new Error(`LEDGER_BUSY_TIMEOUT: begin_failed ${e.message}`);
        }
        sleepSync(RETRY_INTERVAL_MS);
        continue;
      }

      // 语句阶段（INSERT/UPDATE）错误：保留各自语义（唯一约束首写竞态/BUSY 重试），其余原样上抛
      try {
        if (!ledger) {
          conn.prepare(
            "INSERT INTO ledger(uuid,turns,in_bytes,out_bytes,total_bytes,max_turn_bytes,open_turn_bytes,gen,first_at,last_at,budget_version) VALUES(?,?,?,?,?,?,?,?,?,?,?)"
          ).run(uuid, next.turns, next.inBytes, next.outBytes, next.totalBytes, next.maxTurnBytes, next.openTurnBytes, next.gen, next.firstAt, next.lastAt, BUDGET_VERSION);
        } else {
          const sql = completing
            ? "UPDATE ledger SET out_bytes=?,total_bytes=?,max_turn_bytes=?,open_turn_bytes=0,gen=gen+1,last_at=?,budget_version=? WHERE uuid=? AND gen=?"
            : "UPDATE ledger SET turns=?,in_bytes=?,out_bytes=?,total_bytes=?,max_turn_bytes=?,open_turn_bytes=?,gen=gen+1,last_at=?,budget_version=? WHERE uuid=? AND gen=?";
          const r = completing
            ? conn.prepare(sql).run(next.outBytes, next.totalBytes, next.maxTurnBytes, next.lastAt, BUDGET_VERSION, uuid, ledger.gen)
            : conn.prepare(sql).run(next.turns, next.inBytes, next.outBytes, next.totalBytes, next.maxTurnBytes, next.openTurnBytes, next.lastAt, BUDGET_VERSION, uuid, ledger.gen);
          if (r.changes === 0) {
            conn.exec("ROLLBACK"); // 显式结束本事务
            genConflictRounds += 1;
            if (genConflictRounds >= GEN_CONFLICT_MAX_ROUNDS) {
              discardConn();
              throw new Error(`LEDGER_GEN_CONFLICT_EXHAUSTED: rounds=${genConflictRounds}`);
            }
            sleepSync(RETRY_INTERVAL_MS);
            continue; // ROLLBACK 成功事务已结束，同连接复用
          }
        }
      } catch (e) {
        if (String(e.message).startsWith("LEDGER_GEN_CONFLICT_EXHAUSTED")) throw e;
        let inTx = true;
        try { inTx = conn.isTransaction === true; } catch {}
        if (inTx) { try { conn.exec("ROLLBACK"); } catch {} }
        discardConn(); // ROLLBACK 失败也废弃（v8 第 6 步分支）
        if (isUniqueConstraintError(e) && !ledger) {
          if (remaining() < MIN_REMAINING_MS || attempt >= MAX_ATTEMPTS) {
            throw new Error(`LEDGER_BUSY_TIMEOUT: first_write_conflict_race`);
          }
          sleepSync(RETRY_INTERVAL_MS);
          continue;
        }
        if (/database is locked|SQLITE_BUSY/i.test(String(e.message)) && remaining() >= MIN_REMAINING_MS && attempt < MAX_ATTEMPTS) {
          sleepSync(RETRY_INTERVAL_MS);
          continue;
        }
        throw e; // 语句阶段其余错误保留原语义（P0-1 整改：不与 COMMIT 阶段混淆）
      }

      // COMMIT 阶段独立（P0-1）：报错=LEDGER_COMMIT_UNCERTAIN，连接一律废弃，不计成功不重放
      try {
        conn.exec("COMMIT");
      } catch (e) {
        let inTx = true;
        try { inTx = conn.isTransaction === true; } catch {}
        if (inTx) { try { conn.exec("ROLLBACK"); } catch {} } // 释放写锁供他人；连接仍废弃
        discardConn();
        throw new Error(`LEDGER_COMMIT_UNCERTAIN: ${e.message}（提交结果不确定：不计成功、不重放本轮、连接已废弃）`);
      }

      discardConn();
      return { ...next, uuid, budgetVersion: BUDGET_VERSION };
    }
  } finally {
    discardConn();
  }
}

// 同步 sleep（预算内短等待；Atomics.wait 不阻塞事件循环外的其他线程语义）
function sleepSync(ms) {
  Atomics.wait(new Int32Array(new SharedArrayBuffer(4)), 0, 0, ms);
}

// 运营观察辅助：列出本机账本（只读）
export function listLedgers(dirOverride) {
  const dir = dirOverride ?? join(homedir(), ".agents", "session-usage");
  let db;
  try {
    db = openDbFor(dir);
    ensureSchema(db);
    return db.prepare("SELECT uuid,turns,total_bytes,max_turn_bytes,gen,last_at FROM ledger ORDER BY last_at DESC").all();
  } catch (e) {
    throw new Error(`LEDGER_UNREADABLE: ${e.message}`);
  } finally {
    try { db?.close(); } catch {}
  }
}

export const __internals = { isUniqueConstraintError, dbPath, readdirSync, randomUUID, dirname };
